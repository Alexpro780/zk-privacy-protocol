# zk-privacy-protocol

A minimal Hardhat-based template for building a zk-enabled privacy protocol on EVM-compatible blockchains.

## Features
- Hardhat project structure
- Example Solidity contract stub for a mixer-like privacy pool
- Basic deployment script
- Ready to extend with zk-SNARK / zk-proof integrations

## Tech Stack
- Solidity
- Hardhat
- Node.js

## Getting Started
```bash
npm install
npx hardhat compile
npx hardhat test
```
